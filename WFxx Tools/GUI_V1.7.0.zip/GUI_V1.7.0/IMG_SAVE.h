@	0.bmp
@	1.bmp
@	2.bmp
@	3.bmp
@	4.bmp
@	5.bmp
@	6.bmp
%	C:\Users\kamen.valkov\Desktop\smart home demo\0.bmp
%	C:\Users\kamen.valkov\Desktop\smart home demo\1.bmp
%	C:\Users\kamen.valkov\Desktop\smart home demo\2.bmp
%	C:\Users\kamen.valkov\Desktop\smart home demo\3.bmp
%	C:\Users\kamen.valkov\Desktop\smart home demo\4.bmp
%	C:\Users\kamen.valkov\Desktop\smart home demo\5.bmp
%	C:\Users\kamen.valkov\Desktop\smart home demo\6.bmp
!	7
@	7.bmp
%	C:\Users\kamen.valkov\Desktop\smart home demo\7.bmp
!	8
#	Default
